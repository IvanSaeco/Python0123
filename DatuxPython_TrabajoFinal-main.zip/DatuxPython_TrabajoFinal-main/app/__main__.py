from . import user
print(__name__)